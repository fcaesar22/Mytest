<div class="content__inner">
<header class="content__title">
    <h1>Article Dens Life & Style</h1>
    <div class="col-md-12">
    <?php if ($this->session->flashdata('success')): ?>
    <div class="alert alert-success alert-dismissible fade show"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">×</span></button>
    <?php echo $this->session->flashdata('success'); ?>
    </div>
    <?php endif; ?>
    <?php echo $this->session->flashdata('msg');?>
    </div>
</header>
<div class="card">
    <div class="card-body">
    <div class="row">
        <div class="col-md-6">
            <a href="<?php echo site_url('denslife/add') ?>"><i class="btn btn-light">Add</i></a>
            <a href="" id="test" onclick="test()"><i class="btn btn-light">Upload Video</i></a>
        </div>
        <div class="col-md-12" align="center">
            <h4 class="card-title">Article</h4>
        </div>
    </div>
    <div class="tab-container">
        <ul class="nav nav-tabs nav-fill" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" data-toggle="tab" href="#active_art" role="tab">Active Article</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-toggle="tab" href="#inactive_art" role="tab">Inactive Article</a>
            </li>
        </ul>

        <div class="tab-content">
            <div class="tab-pane active fade show" id="active_art" role="tabpanel">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="mytable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Article Title</th>
                                <th>Article By</th>
                                <th>Category</th>
                                <th>Status Article</th>
                                <th>Status PDF</th>
                                <th>Status Highlight</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            $no = 0;
                            foreach ($denslife1 as $key=>$row)://print_r($denslife);die;
                            $no++;
                        ?>
                        <tr>
                            <td align="center"><?php echo $no;?></td>
                            <td align="center"><?php echo $row['article_title'] ?></td>
                            <td align="center"><?php echo $row['article_by'] ?></td>
                            <td align="center"><?php echo $row['categories']?></td>
                            <td><?php echo $row['active'] == 'N' ? "<button type='button' class='btn btn-outline-danger' disabled>Inactive</button>" : "<button type='button' class='btn btn-outline-success' disabled>Active</button>" ?></td>
                            <td><?php echo $row['pdf_url'] == null ? "<button type='button' class='btn btn-outline-danger' disabled>Inactive</button>" : "<button type='button' class='btn btn-outline-success' disabled>Active</button>" ?></td>
                            <td><?php echo $row['status_highlight'] == 'N' ? "<button type='button' class='btn btn-outline-danger' disabled>Not yet</button>" : "<button type='button' class='btn btn-outline-success' disabled>Already</button>" ?></td>
                            <td align="center">
                                <div class="dropdown">
                                    <button class="btn btn-light dropdown-toggle" data-toggle="dropdown">ACTION</button>
                                    <div class="dropdown-menu dropdown-menu--icon">
                                        <?php if($row['active'] =='N'){
                                        ?>
                                            <a onclick="activeConfirm('<?php echo site_url('denslife/activated/'.$row['article_id']);?>')" href="#!" class="dropdown-item"><i class="zmdi zmdi-layers zmdi-hc-fw"></i>Actived Article</a>
                                        <?php
                                            }
                                        ?>
                                        <?php if($row['active'] =='Y'){
                                        ?>
                                            <a onclick="inactiveConfirm('<?php echo site_url('denslife/inactivated/'.$row['article_id']);?>')" href="#!" class="dropdown-item"><i class="zmdi zmdi-layers-off zmdi-hc-fw"></i>Inactived Article</a>
                                        <?php
                                            }
                                        ?>
                                        <?php if($row['categories'] == strpos($row['categories'], 'Food & Recipes')){
                                        ?>
                                            <a onclick="view_pdf('<?php echo site_url('denslife/viewpdf/'.$row['article_id']);?>')" href="#!" class="dropdown-item"><i class="zmdi zmdi-search-in-file zmdi-hc-fw"></i>Generate PDF</a>
                                        <?php
                                        }
                                        ?>
                                        <a href="<?php echo site_url('denslife/detail/'.$row['article_id']);?>" class="dropdown-item"><i class="zmdi zmdi-search-in-page zmdi-hc-fw"></i>Detail</a>
                                        <a href="<?php echo site_url('denslife/get_edit/'.$row['article_id']);?>" class="dropdown-item"><i class="zmdi zmdi-edit zmdi-hc-fw"></i>Edit</a>
                                        <?php if($row['status_highlight'] =='N'){
                                        ?>
                                            <a href="<?php echo site_url('denslife/get_highlight/'.$row['article_id']);?>" class="dropdown-item"><i class="zmdi zmdi-image-o zmdi-hc-fw"></i>Add Highlight</a>
                                        <?php
                                        }
                                        ?>
                                        <a onclick="deleteConfirm('<?php echo site_url('denslife/delete/'.$row['article_id']);?>')" href="#!" class="dropdown-item"><i class="zmdi zmdi-delete zmdi-hc-fw"></i>Delete</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="tab-pane fade" id="inactive_art" role="tabpanel">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="mytable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Article Title</th>
                                <th>Article By</th>
                                <th>Category</th>
                                <th>Status Article</th>
                                <th>Status PDF</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                            $no = 0;
                            foreach ($denslife2 as $key=>$row)://print_r($denslife);die;
                            $no++;
                        ?>
                        <tr>
                            <td align="center"><?php echo $no;?></td>
                            <td align="center"><?php echo $row['article_title'] ?></td>
                            <td align="center"><?php echo $row['article_by'] ?></td>
                            <td align="center"><?php echo $row['categories']?></td>
                            <td><?php echo $row['active'] == 'N' ? "<button type='button' class='btn btn-outline-danger' disabled>Inactive</button>" : "<button type='button' class='btn btn-outline-success' disabled>Active</button>" ?></td>
                            <td><?php echo $row['pdf_url'] == null ? "<button type='button' class='btn btn-outline-danger' disabled>Inactive</button>" : "<button type='button' class='btn btn-outline-success' disabled>Active</button>" ?></td>
                            <td align="center">
                                <div class="dropdown">
                                    <button class="btn btn-light dropdown-toggle" data-toggle="dropdown">ACTION</button>
                                    <div class="dropdown-menu dropdown-menu--icon">
                                        <?php if($row['active'] =='N'){
                                        ?>
                                            <a onclick="activeConfirm('<?php echo site_url('denslife/activated/'.$row['article_id']);?>')" href="#!" class="dropdown-item"><i class="zmdi zmdi-layers zmdi-hc-fw"></i>Actived Article</a>
                                        <?php
                                            }
                                        ?>
                                        <?php if($row['active'] =='Y'){
                                        ?>
                                            <a onclick="inactiveConfirm('<?php echo site_url('denslife/inactivated/'.$row['article_id']);?>')" href="#!" class="dropdown-item"><i class="zmdi zmdi-layers-off zmdi-hc-fw"></i>Inactived Article</a>
                                        <?php
                                            }
                                        ?>
                                        <?php if($row['categories'] == strpos($row['categories'], 'Food & Recipes')){
                                        ?>
                                            <a onclick="view_pdf('<?php echo site_url('denslife/viewpdf/'.$row['article_id']);?>')" href="#!" class="dropdown-item"><i class="zmdi zmdi-search-in-file zmdi-hc-fw"></i>Generate PDF</a>
                                        <?php
                                        }
                                        ?>
                                        <a href="<?php echo site_url('denslife/detail/'.$row['article_id']);?>" class="dropdown-item"><i class="zmdi zmdi-search-in-page zmdi-hc-fw"></i>Detail</a>
                                        <a href="<?php echo site_url('denslife/get_edit/'.$row['article_id']);?>" class="dropdown-item"><i class="zmdi zmdi-edit zmdi-hc-fw"></i>Edit</a>
                                        <a onclick="deleteConfirm('<?php echo site_url('denslife/delete/'.$row['article_id']);?>')" href="#!" class="dropdown-item"><i class="zmdi zmdi-delete zmdi-hc-fw"></i>Delete</a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    </div>
</div>
</div>

<!--Active banner Confirmation-->
<div class="modal fade" id="activeModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-body" align="center">Are you sure?</div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a id="btn-active" class="btn btn-danger" href="#">Active</a>
            </div>
        </div>
    </div>
</div>

<!--Inactive banner Confirmation-->
<div class="modal fade" id="inactiveModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <div class="modal-body" align="center">Are you sure?</div>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a id="btn-inactive" class="btn btn-danger" href="#">Inactive</a>
            </div>
        </div>
    </div>
</div>

<!-- Logout Delete Confirmation-->
<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-body" align="center" id="exampleModalLabel">Are you sure?</h5>
            </div>
            <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <a id="btn-delete" class="btn btn-danger" href="#">Delete</a>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="<?php echo base_url().'assets/js/datatables.js'?>"></script>
<script type="text/javascript">
    $(document).ready(function(){
        $('#mytable').DataTable();
    });

    function test() { 
        window.open("http://aid.digdaya.co.id/uploader", "_blank"); 
    } 

    function view_pdf(url){
        window.open(url);
    }

    function activeConfirm(url){
        $('#btn-active').attr('href', url);
        $('#activeModal').modal();
    }

    function inactiveConfirm(url){
        $('#btn-inactive').attr('href', url);
        $('#inactiveModal').modal();
    }

    function deleteConfirm(url){
        $('#btn-delete').attr('href', url);
        $('#deleteModal').modal();
    }
</script>

<footer class="footer hidden-xs-down">
<p>© Super Admin Responsive. All rights reserved.</p>
</footer>